#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDD_DIALOG2                             101
#define IDB_SETB                                40002
#define IDC_EDIT                                40002
#define IDB_COUNT                               40003
#define IDC_TITLE                               40003
#define IDC_STACK_LIST                          40004
#define IDB_PUSH                                40005
#define IDC_EDIT_VALUE                          40006
#define IDC_EDIT_A                              40007
#define IDC_EDIT_B                              40008
#define IDB_POPA                                40009
#define IDB_POPB                                40010
#define IDB_SETA                                40011
