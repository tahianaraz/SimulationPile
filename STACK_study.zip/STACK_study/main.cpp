#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"

HINSTANCE hInst;


BOOL CALLBACK DlgMain(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    char temp[24];
    static HWND hwndEdit;
    switch(uMsg)
    {
    case WM_INITDIALOG:
    {
        hwndEdit=GetDlgItem(hDlg, IDC_EDIT)   ;
        return TRUE;
    }

    case IDOK:
    {
        EndDialog(hDlg, 0);
    }
    return TRUE;
    case WM_CLOSE:
    {
        EndDialog(hDlg, 0);
    }
    return TRUE;

    case WM_COMMAND:
    {
        switch(LOWORD(wParam))
        {

        case IDB_SETA:


            DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG2), NULL, (DLGPROC)DlgMain);

            /*  GetDlgItemTextA(Dlg2,IDC_EDIT,temp,22);
              SetDlgItemTextA(hDlg,IDC_EDIT_A,temp);

              EndDialog(hDlg,0);*/





            break;
        case IDB_SETB:




            break;

        case IDB_POPA:
            // len = SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETTOPINDEX, 0,0);
            SendDlgItemMessage(hDlg, IDC_STACK_LIST,LB_GETTEXT, (WPARAM) 0L, (LPARAM) temp);
            SetDlgItemTextA(hDlg,IDC_EDIT_A,temp);
            SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_DELETESTRING, (WPARAM) 0L, (LPARAM) temp);
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==0)
            {
                MessageBox(hDlg,"Vide", "STACK_LIST",MB_OK);
                // SetDlgItemTextA(hDlg,IDC_EDIT_A ,0);
            }

            /* {
                 char temp[24];
                 HWND hList = GetDlgItem(hDlg, IDC_STACK_LIST);
                 int index = SendMessage(hList, LB_GETCURSEL, 0, 0);
                 if (index != LB_ERR)
                 {
                     SendMessage(hList, LB_GETTEXT, index, (LPARAM)temp);
                     SetDlgItemText(hDlg, IDC_EDIT_A, temp);
                 }
             }*/





            break;
        case IDB_POPB:
            //   len = SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETTOPINDEX, 0,0);
            SendDlgItemMessage(hDlg, IDC_STACK_LIST,LB_GETTEXT, (WPARAM) 0L, (LPARAM) temp);
            SetDlgItemTextA(hDlg,IDC_EDIT_B,temp);
            SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_DELETESTRING, (WPARAM) 0L, (LPARAM) temp);
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==0)
            {
                MessageBox(hDlg,"Vide", "STACK_LIST",MB_OK);

            }
            break;
        case IDB_PUSH:
            GetDlgItemTextA(hDlg, IDC_EDIT_VALUE, temp, 22);
            SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_ADDSTRING, (WPARAM) 0L, (LPARAM) temp);
            break;
        case IDB_COUNT:

            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==0)
            {
                MessageBox(hDlg,"0", "NOMBRES",MB_OK);
            }

            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==1)
            {
                MessageBox(hDlg,"1", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==2)
            {
                MessageBox(hDlg,"2", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==3)
            {
                MessageBox(hDlg,"3", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==4)
            {
                MessageBox(hDlg,"4", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==5)
            {
                MessageBox(hDlg,"5", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==6)
            {
                MessageBox(hDlg,"6", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==7)
            {
                MessageBox(hDlg,"7", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==8)
            {
                MessageBox(hDlg,"8", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==9)
            {
                MessageBox(hDlg,"9", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==10)
            {
                MessageBox(hDlg,"10", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==11)
            {
                MessageBox(hDlg,"11", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==12)
            {
                MessageBox(hDlg,"12", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==13)
            {
                MessageBox(hDlg,"13", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==14)
            {
                MessageBox(hDlg,"14", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==15)
            {
                MessageBox(hDlg,"15", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==16)
            {
                MessageBox(hDlg,"16", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==17)
            {
                MessageBox(hDlg,"17", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==18)
            {
                MessageBox(hDlg,"18", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==19)
            {
                MessageBox(hDlg,"19", "NOMBRES",MB_OK);
            }
            if(SendDlgItemMessage(hDlg, IDC_STACK_LIST, LB_GETCOUNT,(WPARAM) 0,(LPARAM)  temp)==20)
            {
                MessageBox(hDlg,"20", "NOMBRES",MB_OK);
            }




            break;
        /*   case IDOK:
        HWND Dlg = GetParent(hDlg);
        GetDlgItemText(Dlg, IDC_EDIT,temp,22);
        SetDlgItemText(hDlg,IDC_EDIT_A,temp);
        EndDialog(Dlg,0);*/

        case IDCANCEL:
            EndDialog(hDlg, 0);
            break;

        }
    }
    return TRUE;
    }
    return FALSE;
}
/*
BOOL CALLBACK DlgMain2(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
     char temp[24];
     static HWND hwndEdit;
//        HWND hDlg = GetParent(hDlg);
 switch(Msg)
    {
    case WM_INITDIALOG:
    {
 hwndEdit=GetDlgItem(hDlg,IDC_EDIT);
 return TRUE;
    }

    case IDOK:
    {
        if(LOWORD(wParam)==IDB_SETA){
        GetWindowText(hwndEdit,temp,22);
       HWND Dlg= FindWindow(NULL, TEXT(temp));
        EndDialog(hDlg, 0);
        }
    }*/





int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    hInst=hInstance;
    InitCommonControls();
    return DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DlgMain);
}
